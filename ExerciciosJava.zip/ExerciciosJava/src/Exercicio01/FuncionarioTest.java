package Exercicio01;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class FuncionarioTest {

    public static void main(String[] args) {

        Funcionario func = new Funcionario();

        Scanner sc = new Scanner(System.in);

        System.out.println("Digite o ID do funcionário: ");
        func.setIdFunc(Integer.parseInt(sc.nextLine()));

        System.out.println("Digite o Nome do funcionário: ");
        func.setNomeFunc(sc.nextLine());

        System.out.println("Digite o departamento: ");
        func.setDepartamento(sc.nextLine());

        System.out.println("Digite a data da contratação (dd/mm/aaaa): ");
        String dataDigitada = sc.nextLine();
        DateTimeFormatter form = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate dataContratacao = LocalDate.parse(dataDigitada, form);
        //System.out.println(dataContratacao.format(form));
        func.setDataContratacao(dataContratacao);

        System.out.println("Digite o salário: ");
        func.setSalario(Double.parseDouble(sc.nextLine()));

        System.out.println("Digite o documento: ");
        func.setDocumento(sc.nextLine());

        func.setAtivo(true);

        System.out.println("Digite um valor para ser acrescido ao salário: ");
        double salario = Double.parseDouble(sc.nextLine());
        func.atualizarSalario(salario);

        func.imprimir();
        System.out.println("");
        func.demiteFuncionario();
        func.imprimir();

    }
}
