package Exercicio04;

import Exercicio03.Porta;

import javax.sound.sampled.Port;

public class Casa {
    //Atributos
    private String cor;
    public Porta porta1;
    public Porta porta2;
    public Porta porta3;

    //Métodos
    public void pinta(String cor){
        this.cor = cor;
        System.out.println("Você pintou a casa de " + this.cor);
    }

    public int quantasPortasEstaoAbertas(){
        int cont = 0;
        if(porta1.aberta){
            cont++;
        }
        if(porta2.aberta){
            cont++;
        }
        if(porta3.aberta){
            cont++;
        }
        return cont;
    }

    //getters and setters
    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }
}
