package Exercicio04;

import Exercicio03.Porta;

import java.util.Scanner;

public class Main04 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        Casa casa1 = new Casa();

        System.out.println("Qual cor deseja pintar a casa?");
        casa1.pinta(sc.nextLine());

        casa1.porta1 = new Porta();
        casa1.porta2 = new Porta();
        casa1.porta3 = new Porta();
        System.out.println("Estão abertas " + casa1.quantasPortasEstaoAbertas() + " portas.");

        casa1.porta1.fecha();
        casa1.porta2.abre();
        casa1.porta3.fecha();
        System.out.println("Estão abertas " + casa1.quantasPortasEstaoAbertas() + " portas.");

        casa1.porta1.abre();
        casa1.porta2.fecha();
        casa1.porta3.abre();
        System.out.println("Estão abertas " + casa1.quantasPortasEstaoAbertas() + " portas.");

        System.out.println("A casa " + casa1.getCor() + " possui " + casa1.quantasPortasEstaoAbertas() + " portas abertas.");

    }
}
