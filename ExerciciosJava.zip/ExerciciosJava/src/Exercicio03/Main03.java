package Exercicio03;

import java.util.Scanner;

public class Main03 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Porta porta1 = new Porta();

        System.out.println("Insira a dimensão X: ");
        porta1.setDimensaoX(Double.parseDouble(sc.nextLine()));

        System.out.println("Insira a dimensão Y: ");
        porta1.setDimensaoY(Double.parseDouble(sc.nextLine()));

        System.out.println("Insira a dimensão Z: ");
        porta1.setDimensaoZ(Double.parseDouble(sc.nextLine()));

        System.out.println("Insira a cor da porta: ");
        String cor = sc.nextLine();
        porta1.pinta(cor);

        porta1.abre();
        System.out.println(porta1.estaAberta());;

        porta1.imprimir();

        porta1.fecha();
        System.out.println(porta1.estaAberta());

        porta1.imprimir();

    }
}
