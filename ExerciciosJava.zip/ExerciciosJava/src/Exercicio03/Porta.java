package Exercicio03;

public class Porta {
    //Atributos
    public double dimensaoX;
    public double dimensaoY;
    public double dimensaoZ;
    public String cor;
    public boolean aberta;

    //Métodos
    public void abre(){
        this.aberta = true;
    }

    public void fecha(){
        this.aberta = false;
    }

    public void pinta(String cor){
        this.cor = cor;
    }

    public boolean estaAberta(){
        return this.aberta;
    }

    public void imprimir(){
        System.out.println("cor = " + cor);
        System.out.println("aberta = " + aberta);
        System.out.println("dimensaoX = " + dimensaoX);
        System.out.println("dimensaoY = " + dimensaoY);
        System.out.println("dimensaoZ = " + dimensaoZ);
    }


    //Gets and Setters
    public double getDimensaoX() {
        return dimensaoX;
    }
    public void setDimensaoX(double dimensaoX) {
        this.dimensaoX = dimensaoX;
    }
    public double getDimensaoY() {
        return dimensaoY;
    }
    public void setDimensaoY(double dimensaoY) {
        this.dimensaoY = dimensaoY;
    }
    public double getDimensaoZ() {
        return dimensaoZ;
    }
    public void setDimensaoZ(double dimensaoZ) {
        this.dimensaoZ = dimensaoZ;
    }
    public String getCor() {
        return cor;
    }
    public void setCor(String cor) {
        this.cor = cor;
    }
    public boolean isAberta() {
        return aberta;
    }
    public void setAberta(boolean aberta) {
        this.aberta = aberta;
    }
}
