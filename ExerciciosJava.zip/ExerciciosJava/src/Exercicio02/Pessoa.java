package Exercicio02;

import java.time.LocalDate;
import java.time.Period;

public class Pessoa {
    //Atributos
    public String nome;
    public LocalDate nascimento;//yyyy-MM-dd
    public int idade;


    //Métodos
    public void imprimir(){
        System.out.println("nome = " + nome);
        System.out.println("nascimento = " + nascimento);
        System.out.println("idade = " + idade + " anos");
    }

    public void dataNascimento(LocalDate nascimento){
        this.nascimento = nascimento;
    }

    public void fazAniversario(LocalDate data){
        this.idade = Period.between(this.nascimento, data).getYears();
        //this.idade = data.compareTo(this.nascimento);
    }

    //Getters and Setters
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public LocalDate getNascimento() {
        return nascimento;
    }
    public void setNascimento(LocalDate nascimento) {
        this.nascimento = nascimento;
    }
    public int getIdade() {
        return idade;
    }
    public void setIdade(int idade) {
        this.idade = idade;
    }
}
