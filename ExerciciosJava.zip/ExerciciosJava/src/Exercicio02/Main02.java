package Exercicio02;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main02 {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Pessoa pessoa1 = new Pessoa();
        System.out.println("Insira o nome da pessoal: ");
        pessoa1.setNome(sc.nextLine());

        System.out.println("Insira a data de nascimento da pessoa (dd/mm/aaaa): ");
        String dataDigitada = sc.nextLine();
        DateTimeFormatter form = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        LocalDate dataAniversario = LocalDate.parse(dataDigitada, form);
        pessoa1.setNascimento(dataAniversario);
        pessoa1.fazAniversario(LocalDate.now());

        System.out.println("Segundo a data de hoje (" + LocalDate.now() + ")");
        pessoa1.imprimir();
        System.out.println("-----------------------------------------");

        System.out.println("Insira uma data para alterar a idade (dd/mm/aaaa): ");
        dataDigitada = sc.nextLine();
        dataAniversario = LocalDate.parse(dataDigitada, form);
        pessoa1.fazAniversario(dataAniversario);
        pessoa1.imprimir();
        System.out.println("-----------------------------------------");

        System.out.println("Insira uma data para alterar a idade (dd/mm/aaaa): ");
        dataDigitada = sc.nextLine();
        dataAniversario = LocalDate.parse(dataDigitada, form);
        pessoa1.fazAniversario(dataAniversario);
        pessoa1.imprimir();
        System.out.println("-----------------------------------------");

    }
}
