package Exercicio05;

import java.util.Random;

public class Cartela {
    //Atributos
    public int numeros [] = new int[24];


    //Métodos

    //gerar numeros da cartela
    public void gerarCartela(){
        Random geradorCartela = new Random();
        int cont=0;

        //while pra preencher a cartela enquanto o último espaço do vetor for zero(default)
        while(numeros[numeros.length-1] == 0){

            int num = geradorCartela.nextInt(75);
            //se o número for zero, continua o while
            if(num == 0){
                continue;
            }

            //verifica se o número aleatório já existe na cartela, se existe altera o boolean pra true
            boolean jaExiste = false;
            for(int i = 0; i < numeros.length; i++){
                if (numeros[i] == num){
                    jaExiste = true;
                }
            }
            //se o boolean foi alterado no laço anterior ele pula o while
            if(jaExiste == true){
                continue;
            }
            //Atribui o número novo à cartela
            numeros[cont] = num;
            cont++;

        }

    }

    //imprimir Cartela
    public void imprimir(){
        System.out.printf("Números da Cartela = ");
        for(int i = 0; i < numeros.length; i++){
            System.out.printf("%d, ", numeros[i]);
        }
        System.out.println("");
    }

    //compararNumeros
    public boolean compararNumeros(int aux){
        boolean retorno = false;

        for(int i = 0; i < numeros.length; i++){
            if(numeros[i] == aux){
                retorno  = true;
            }else{
                retorno = false;
            }
        }
        return retorno;
    }

    //Getters and Setters


    public int[] getNumeros() {
        return numeros;
    }

    public void setNumeros(int[] numeros) {
        this.numeros = numeros;
    }
}
