package Exercicio05;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Main05 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        //CRIANDO JOGADR E SUA CARTELA

        Jogador jogador1 = new Jogador();

        System.out.println("insira o nome do Jogador: ");
        jogador1.setNome(sc.nextLine());
        jogador1.criarCartelaJogador();

        jogador1.imprimir();


        //----------------------------------------------------------------
        //CRIANDO O SORTEIO

        Random numeroSorteado = new Random();
        int aux; //variável que receberá o número aleatório
        int matchNumero = 0;//variável que irá verificar se o número sorteado é o mesmo da cartela do jogador
        int numeroRetirado = 0;
        int rodada = 0;


        //Cria a lista que será usada para o sorteio
        ArrayList numerosParaRetirar = new ArrayList();

        //Preenche a lista com números de 1 a 75
        for(int i = 0; i < 75; i++){
            numerosParaRetirar.add(i+1);
        }

        System.out.println("SORTEANDO!");
        //Acontece enquanto existem números na lista
        while(matchNumero != 24){
            rodada++;
            aux = numeroSorteado.nextInt(numerosParaRetirar.size());//recebe um número aleatório dentro do tamanho da lista
            System.out.println("Sorteado o número " + numerosParaRetirar.get(aux) + "!");//mostra qual o número foi sorteado


            numeroRetirado = Integer.parseInt((String.valueOf(numerosParaRetirar.get(aux))));
            System.out.println("Aqui imprimindo o número a ser retirado = " + numeroRetirado);

            //for para comparar o número retirado do
            for(int i=0; i< jogador1.cartela.numeros.length; i++){
                if(jogador1.cartela.numeros[i] == numeroRetirado){
                    System.out.println("TEM ESSE NUMERO!!!");
                    matchNumero++;
                }
            }

            numerosParaRetirar.remove(aux);//retira o número da lista que está no índice aleatório (aux)
            System.out.println(numerosParaRetirar);//imprime a lista com número retirado
        }

        System.out.println("Foram necessárias " + rodada + " rodadas para o Jogador vencer! BINGO!!!");


    }



}
