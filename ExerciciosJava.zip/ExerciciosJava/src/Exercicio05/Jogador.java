package Exercicio05;

public class Jogador {

    //Atributos
    private String nome;
    public Cartela cartela;

    //Métodos
    public void criarCartelaJogador(){
        this.cartela = new Cartela();
        this.cartela.gerarCartela();
    }

    public void imprimir(){
        System.out.println("nome = " + nome);
        cartela.imprimir();
    }


    //Getters and Setters
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
